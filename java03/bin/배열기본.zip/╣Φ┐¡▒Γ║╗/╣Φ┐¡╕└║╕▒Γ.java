package 배열기본;

public class 배열맛보기 {

	public static void main(String[] args) {
		int 정답[] = {1, 1, 2, 3};
		
		System.out.println(정답);
		
		int 내답[] = {1,2,4,3};
		
		//무더기에 저장될 데이터를 처음에 모르고 있다가
		//나중에 넣는경우 
		
		//double 배열 
		double height[] = {123.4 , 234.2, 124.5};
		double rep[] = new double[500];
		
		//char 배열 
		char gender[] = {'남','여','남'};
		
		//String 배열 
		String rep2[] = new String[333];
	}

}
